#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int getlength(string str)
{
    int count = 0;
    while (str[count] != '\0')
    {
        count++;
    }
    return count;
}

void updatecgpa()
{
    string regno, newcgpa, line;
    cout << "enter registration number: ";
    getline(cin, regno);
    cout << "enter updated cgpa: ";
    getline(cin, newcgpa);

    ifstream file("data.csv");
    ofstream temp("temp.csv");

    if (!file || !temp)
    {
        cout << "error opening file!" << endl;
        return;
    }

    bool found = false;
    int regnolen = getlength(regno);

    while (getline(file, line))
    {
        bool match = true;
        for (int i = 0; i < regnolen; i++)
        {
            if (line[i] != regno[i])
            {
                match = false;
                break;
            }
        }

        if (match)
        {
            int part = 0;
            for (int i = 0; line[i] != '\0'; i++)
            {
                if (line[i] == ',')
                {
                    part++;
                }
                temp << line[i];
                if (part == 2)
                {
                    temp << newcgpa;
                    found = true;
                    while (line[i] != '\0')
                    {
                        i++;
                    }
                    break;
                }
            }
            temp << endl;
        }
        else
        {
            temp << line << endl;
        }
    }

    file.close();
    temp.close();

    if (found)
    {
        remove("data.csv");
        rename("temp.csv", "data.csv");
        cout << "cgpa updated " << endl;
    }
    else
    {
        remove("temp.csv");
        cout << "no record found for " << regno << endl;
    }
}

int main()
{
    updatecgpa();
    return 0;
}
