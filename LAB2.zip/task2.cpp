#include <iostream>
#include <fstream>
#include <string>

using namespace std;

void addrecord()
{
    string regno, name, dept;
    cout << "enter registration number: ";
    getline(cin, regno);
    cout << "enter name: ";
    getline(cin, name);
    cout << "enter department: ";
    getline(cin, dept);

    ofstream file("data.csv", ios::app);

    if (!file)
    {
        cout << "error opening file!" << endl;
        return;
    }

    file << regno << "," << name << "," << dept << endl;
    cout << "record added ." << endl;

    file.close();
}

int main()
{
    addrecord();
    return 0;
}
