#include <iostream>
#include <fstream>
#include <string>

using namespace std;

int getlength(string str)
{
    int count = 0;
    while (str[count] != '\0')
    {
        count++;
    }
    return count;
}

void deleterecord()
{
    string regno, line;
    cout << "enter registration number: ";
    getline(cin, regno);

    ifstream file("data.csv");
    ofstream temp("temp.csv");

    if (!file || !temp)
    {
        cout << "error opening file!" << endl;
        return;
    }

    bool found = false;
    int regnolen = getlength(regno);

    while (getline(file, line))
    {
        bool match = true;
        for (int i = 0; i < regnolen; i++)
        {
            if (line[i] != regno[i])
            {
                match = false;
                break;
            }
        }

        if (match)
        {
            found = true;
        }
        else
        {
            temp << line << endl;
        }
    }

    file.close();
    temp.close();

    if (found)
    {
        remove("data.csv");
        rename("temp.csv", "data.csv");
        cout << "record deleted successfully." << endl;
    }
    else
    {
        remove("temp.csv");
        cout << "no record found for " << regno << endl;
    }
}

int main()
{
    deleterecord();
    return 0;
}
