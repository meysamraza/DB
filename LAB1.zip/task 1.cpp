#include <fstream>
#include <iostream>
#include <string>
using namespace std;

void write(int size)
{
    ofstream data("data.csv");
    if (!data)
    {
        cout << "cant open file..\n";
        return;
    }

    if (data.tellp() == 0)
    {
        data << "registration,firstname,lastname,program,number,gpa" << endl;
    }

    string reg, lname, fname, prog;
    float gpa;
    int num;

    for (int i = 0; i < size; i++)
    {
        cout << "enter registration, first name, last name, program, number, and gpa: " << endl;
        cin >> reg >> fname >> lname >> prog >> num >> gpa;
        data << reg << "," << fname << "," << lname << "," << prog << "," << num << "," << gpa << endl;
    }

    data.close();
}

void append(int size)
{
    ofstream data("data.csv", ios::app);
    if (!data)
    {
        cout << "cant open file..\n";
        return;
    }

    string reg, lname, fname, prog;
    float gpa;
    int num;

    for (int i = 0; i < size; i++)
    {
        cout << "enter registration, first name, last name, program, number, and gpa: " << endl;
        cin >> reg >> fname >> lname >> prog >> num >> gpa;
        data << reg << "," << fname << "," << lname << "," << prog << "," << num << "," << gpa << endl;
    }

    data.close();
}

void read()
{
    ifstream data("data.csv");
    if (!data)
    {
        cout << "cant open file..\n";
        return;
    }

    string line;
    while (getline(data, line))
    {
        cout << line << endl;
    }

    data.close();
}

int main()
{
    int size;
    cout << "enter number of students to enter: ";
    cin >> size;

    write(size);

    char cont;
    cout << "enter 1 to append more data or 0 to exit: ";
    cin >> cont;

    if (cont == '1')
    {
        cout << "enter extra students to enter: ";
        cin >> size;
        append(size);
    }

    cout << "current data in file:\n";
    read();

    return 0;
}
