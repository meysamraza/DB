#include <fstream>
#include <iostream>
#include <string>
using namespace std;

void display()
{
    ifstream data("employee.csv");
    if (!data)
    {
        cout << "cant open file..\n";
        return;
    }

    string id, name, date, dept, contact, salary, status;

    string header;
    getline(data, header);

    while (data.good())
    {
        getline(data, id, ',');
        getline(data, name, ',');
        getline(data, date, ',');
        getline(data, dept, ',');
        getline(data, contact, ',');
        getline(data, salary, ',');
        getline(data, status);

        int msalary = 0;

        int ysalary = msalary * 12;

        if (ysalary >= 1500000)
        {
            cout << name << " earns " << ysalary << " per year\n";
        }
    }

    data.close();
}

int main()
{
    display();
    return 0;
}
