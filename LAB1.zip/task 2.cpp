#include <fstream>
#include <iostream>
#include <string>
using namespace std;

void findcgpa()
{
    ifstream data("data.csv");
    if (!data)
    {
        cout << "cant open file..\n";
        return;
    }

    string reg, fname, lname, prog;
    int num;
    float gpa;

    string header;
    getline(data, header); 

    while (data.good())
    {
        getline(data, reg, ',');
        getline(data, fname, ',');
        getline(data, lname, ',');
        getline(data, prog, ',');
        data >> num;
        data.ignore();
        data >> gpa;
        data.ignore();

        if (gpa >= 3.5)
        {
            cout << fname << " " << lname << " has gpa of : " << gpa << endl;
        }
    }

    data.close();
}

int main()
{
    findcgpa();
    return 0;
}
