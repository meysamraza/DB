#include <fstream>
#include <iostream>
#include <string>
using namespace std;

string getresid()
{
    ifstream deptfile("department.csv");
    if (!deptfile)
    {
        cout << "cant open department file\n";
        return "";
    }

    string id, name;
    deptfile >> id >> name; 

    while (deptfile >> id >> name)
    {
        if (name == "Research")
        {
            deptfile.close();
            return id;
        }
    }

    deptfile.close();
    return "";
}

void findres()
{
    string researchid = getresid();
    if (researchid == "")
    {
        cout << "research department not found\n";
        return;
    }

    ifstream empfile("employee.csv");
    if (!empfile)
    {
        cout << "cant open employee file\n";
        return;
    }

    string id, name, date, dept, contact, salary, status;
    empfile >> id >> name >> date >> dept >> contact >> salary >> status; 

    while (empfile >> id >> name >> date >> dept >> contact >> salary >> status)
    {
        if (dept == researchid)
        {
            cout << name << " works in research department\n";
        }
    }

    empfile.close();
}

int main()
{
    findres();
    return 0;
}
